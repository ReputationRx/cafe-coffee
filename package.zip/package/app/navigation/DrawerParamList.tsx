export type DrawerParamList = {
    BottomTab: undefined;
};