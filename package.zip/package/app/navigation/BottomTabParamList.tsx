export type BottomTabParamList = {
    Home: undefined;
    Wishlist: undefined;
    MyCart: undefined;
    Category: undefined;
    Profile: undefined;
};